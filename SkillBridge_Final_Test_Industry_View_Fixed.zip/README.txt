SkillBridge Fresh Rebuild
==========================
Open index.html in a browser.

Flow:
Student Profile -> Save Profile & Continue -> Main Menu

Main Menu:
- Student Skill Journey
- Academician Hub
- Jobs & Internships
- Industry View

This build uses one simple HTML file and vanilla JavaScript so profile submission
and module navigation do not depend on the previous prototype's scripts.
