SkillBridge - Final Test + Industry View Fixed

Updated in this version:
- Added Edit Profile button after profile creation.
- Existing profile values are loaded back into the form for editing.
- Name, education, career goal details can be updated.
- Existing skill-assessment/final-test progress is preserved when only profile details change.
- Changing the Career Goal resets skill verification because the required skill set changes.
- Added Cancel option while editing.
- Existing first-assessment, final-readiness, jobs lock/unlock, and Industry View behavior remains unchanged.
